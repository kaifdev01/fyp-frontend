"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Bell,
  MessageSquare,
  Search,
  User,
  Settings,
  LogOut,
  Briefcase,
  DollarSign,
  Star,
  ChevronDown
} from "lucide-react";

export default function FreelancerHeader() {
  const [user, setUser] = useState(null);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const userData = localStorage.getItem("user");
    if (userData && userData !== "undefined") {
      try {
        setUser(JSON.parse(userData));
      } catch (error) {
        localStorage.removeItem("user");
      }
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    router.push("/login");
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-white border-b border-gray-200 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">

          {/* Logo & Brand */}
          <div className="flex items-center">
            <Link href="/freelancer-dashboard" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">WD</span>
              </div>
              <span className="text-xl font-bold text-gray-900">WorkDeck</span>
            </Link>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/freelancer-dashboard" className="text-blue-600 font-medium hover:text-blue-700">
              Dashboard
            </Link>
            <Link href="/browse-jobs" className="text-gray-600 hover:text-gray-900 font-medium">
              Browse Jobs
            </Link>
            <Link href="/my-proposals" className="text-gray-600 hover:text-gray-900 font-medium">
              My Proposals
            </Link>
            <Link href="/my-projects" className="text-gray-600 hover:text-gray-900 font-medium">
              My Projects
            </Link>
          </nav>

          {/* Right Side - Stats & Actions */}
          <div className="flex items-center space-x-4">

            {/* Quick Stats */}
            <div className="hidden lg:flex items-center space-x-6 text-sm">
              <div className="flex items-center space-x-1 text-gray-600">
                <Briefcase size={16} />
                <span>0 Active</span>
              </div>
              <div className="flex items-center space-x-1 text-gray-600">
                <DollarSign size={16} />
                <span>${user?.totalEarnings || 0}</span>
              </div>
              <div className="flex items-center space-x-1 text-gray-600">
                <Star size={16} />
                <span>{user?.rating || 0.0}</span>
              </div>
            </div>

            {/* Messages */}
            <button className="relative p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors">
              <MessageSquare size={20} />
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                0
              </span>
            </button>

            {/* Notifications */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <Bell size={20} />
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                  0
                </span>
              </button>

              {/* Notifications Dropdown */}
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-lg border border-gray-200 py-2 z-50">
                  <div className="px-4 py-2 border-b border-gray-100">
                    <h3 className="font-semibold text-gray-900">Notifications</h3>
                  </div>
                  <div className="p-4 text-center text-gray-500 text-sm">
                    No new notifications
                  </div>
                </div>
              )}
            </div>

            {/* Profile Menu */}
            <div className="relative">
              <button
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
                  {user?.avatar ? (
                    <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-sm font-medium text-gray-600">{user?.name?.[0]}</span>
                  )}
                </div>
                <div className="hidden md:block text-left">
                  <p className="text-sm font-medium text-gray-900">{user?.name?.split(' ')[0]}</p>
                  <p className="text-xs text-gray-500">Freelancer</p>
                </div>
                <ChevronDown size={16} className="text-gray-400" />
              </button>

              {/* Profile Dropdown */}
              {showProfileMenu && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-gray-200 py-2 z-50">
                  <div className="px-4 py-3 border-b border-gray-100">
                    <p className="font-medium text-gray-900">{user?.name}</p>
                    <p className="text-sm text-gray-500">{user?.email}</p>
                  </div>

                  <Link href="/edit-profile" className="flex items-center space-x-2 px-4 py-2 text-gray-700 hover:bg-gray-50">
                    <User size={16} />
                    <span>View Profile</span>
                  </Link>



                  {user?.roles?.length > 1 && (
                    <Link href={user.roles.includes('client') ? '/client-dashboard' : '/freelancer-dashboard'} className="flex items-center space-x-2 px-4 py-2 text-gray-700 hover:bg-gray-50">
                      <Star size={16} />
                      <span>Switch to {user.roles.includes('client') ? 'Client' : 'Freelancer'}</span>
                    </Link>
                  )}

                  <Link href="/settings" className="flex items-center space-x-2 px-4 py-2 text-gray-700 hover:bg-gray-50">
                    <Settings size={16} />
                    <span>Settings</span>
                  </Link>

                  <hr className="my-2" />

                  <button
                    onClick={handleLogout}
                    className="flex items-center space-x-2 px-4 py-2 text-red-600 hover:bg-red-50 w-full text-left"
                  >
                    <LogOut size={16} />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}