import { Inter } from 'next/font/google'
import './globals.css'
import SessionWrapper from '../components/SessionWrapper'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'WorkDeck - Hire the best freelancers',
  description: 'Find and hire skilled freelancers for your projects',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <SessionWrapper>
          {children}
        </SessionWrapper>
      </body>
    </html>
  )
}