'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import FreelancerHeader from '../../components/FreelancerHeader';
import ProtectedRoute from '../../components/ProtectedRoute';
import api from '../../lib/api';
import toast from 'react-hot-toast';
import {
  Search,
  MapPin,
  DollarSign,
  Clock,
  Star,
  Eye,
  Calendar,
  Award,
  TrendingUp,
  Edit,
  ExternalLink,
  RefreshCw
} from 'lucide-react';

export default function FreelancerDashboard() {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Fetch dashboard data from backend
  const fetchDashboardData = async () => {
    try {
      const response = await api.get('/api/freelancer/dashboard');
      setDashboardData(response.data.data);

      // Update localStorage with fresh user data
      localStorage.setItem('user', JSON.stringify(response.data.data.user));

    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Refresh dashboard data
  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchDashboardData();
  };

  if (loading) {
    return (
      <ProtectedRoute>
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <RefreshCw className="animate-spin mx-auto mb-4 text-blue-600" size={32} />
            <p className="text-gray-600">Loading dashboard...</p>
          </div>
        </div>
      </ProtectedRoute>
    );
  }

  const { user, analytics, portfolio, stats } = dashboardData || {};

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gray-50">
        <FreelancerHeader />

        <div className="pt-24 pb-16 px-4">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">

            {/* Main Content Area */}
            <div className="lg:col-span-2 space-y-6">
              {/* Stats / Welcome Banner */}
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-8 text-white shadow-xl">
                <div className="flex justify-between items-start">
                  <div>
                    <h1 className="text-3xl font-bold mb-2">Welcome back, {user?.name?.split(' ')[0] || 'Freelancer'}! 👋</h1>
                    <p className="text-blue-100">You have {stats?.activeProjects || 0} active projects and {stats?.totalProposals || 0} proposals.</p>
                  </div>
                  <button
                    onClick={handleRefresh}
                    disabled={refreshing}
                    className="p-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors"
                  >
                    <RefreshCw className={`text-white ${refreshing ? 'animate-spin' : ''}`} size={20} />
                  </button>
                </div>
              </div>

              {/* Search Bar */}
              <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100 flex items-center gap-4">
                <Search className="text-gray-400" />
                <input
                  type="text"
                  placeholder="Search for projects (e.g. React, Design...)"
                  className="flex-1 outline-none text-gray-700"
                />
                <button className="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                  Search
                </button>
              </div>

              {/* Sample Job (Placeholder) */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow cursor-pointer">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-gray-800">E-commerce Website Redesign</h3>
                    <p className="text-sm text-gray-500 mt-1">Posted 2 hours ago</p>
                  </div>
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold">
                    New
                  </span>
                </div>
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                  Looking for an experienced UI/UX designer to redesign our Shopify store. Must have experience with Figma and improving conversion rates...
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-medium">Shopify</span>
                  <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-medium">UI/UX</span>
                  <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-medium">Figma</span>
                </div>
                <div className="flex items-center gap-6 text-sm text-gray-500 border-t border-gray-100 pt-4">
                  <div className="flex items-center gap-1"><DollarSign size={16} /> $2,000 - $3,000</div>
                  <div className="flex items-center gap-1"><Clock size={16} /> 2-3 weeks</div>
                  <div className="flex items-center gap-1"><MapPin size={16} /> Remote</div>
                </div>
              </div>
            </div>

            {/* Right Sidebar - Enhanced Profile Card */}
            <div className="lg:col-span-1 space-y-6">
              {/* Profile Card */}
              <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
                <div className="h-20 bg-gradient-to-r from-blue-500 to-indigo-500"></div>
                <div className="px-6 pb-6">
                  <div className="relative -mt-10 mb-4 flex justify-center">
                    <div className="w-20 h-20 rounded-full bg-white p-1 shadow-lg">
                      <div className="w-full h-full rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
                        {user?.avatar ? (
                          <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
                        ) : (
                          <span className="text-2xl font-bold text-gray-500">{user?.name?.[0]}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="text-center mb-6">
                    <h2 className="text-xl font-bold text-gray-900">{user?.name}</h2>
                    <p className="text-blue-600 font-medium text-sm mb-2">Freelancer</p>
                    {user?.intro && (
                      <p className="text-gray-600 text-sm mb-3 line-clamp-2">{user.intro}</p>
                    )}
                    <div className="flex justify-center items-center gap-1 text-yellow-500">
                      <Star size={16} fill="currentColor" />
                      <span className="font-bold text-gray-700">{user?.rating || 0.0}</span>
                      <span className="text-gray-400 text-xs">({user?.completedProjects || 0} reviews)</span>
                    </div>
                  </div>

                  {/* Profile Completion */}
                  <div className="mb-6 p-4 bg-gray-50 rounded-xl">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Profile Completion</span>
                      <span className="text-sm font-bold text-blue-600">{analytics?.profileCompletion || 0}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${analytics?.profileCompletion || 0}%` }}
                      ></div>
                    </div>
                    {(analytics?.profileCompletion || 0) < 100 && (
                      <p className="text-xs text-gray-500 mt-2">Complete your profile to get more opportunities</p>
                    )}
                  </div>

                  {/* Skills */}
                  {user?.skills?.length > 0 && (
                    <div className="mb-6">
                      <h3 className="text-sm font-semibold text-gray-700 mb-3">Top Skills</h3>
                      <div className="flex flex-wrap gap-2">
                        {user.skills.slice(0, 4).map((skill, index) => (
                          <span key={index} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
                            {skill}
                          </span>
                        ))}
                        {user.skills.length > 4 && (
                          <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-medium">
                            +{user.skills.length - 4} more
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="space-y-3 mb-6">
                    <div className="flex justify-between items-center py-2 border-t border-gray-100">
                      <span className="text-sm text-gray-500">Hourly Rate</span>
                      <span className="font-bold text-gray-900">${user?.hourlyRate || 0}/hr</span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-t border-gray-100">
                      <span className="text-sm text-gray-500">Location</span>
                      <span className="font-bold text-gray-900">{user?.location || 'Remote'}</span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-t border-gray-100">
                      <span className="text-sm text-gray-500">Total Earnings</span>
                      <span className="font-bold text-green-600">${user?.totalEarnings || 0}</span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Link
                      href="/edit-profile"
                      className="w-full bg-blue-600 text-white py-2.5 rounded-xl font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                    >
                      <Edit size={16} />
                      Edit Profile
                    </Link>

                    <Link
                      href={`/public-profile/${user?.id}`}
                      className="w-full border border-blue-600 text-blue-600 py-2.5 rounded-xl font-semibold hover:bg-blue-50 transition-colors flex items-center justify-center gap-2"
                    >
                      <ExternalLink size={16} />
                      View Public Profile
                    </Link>
                  </div>
                </div>
              </div>

              {/* Profile Management Section */}
              <div className="bg-white rounded-2xl shadow-sm border border-blue-600 p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Profile Management</h3>

                {/* Profile Views */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Eye size={16} className="text-blue-600" />
                      <span className="text-sm font-medium text-gray-700">Profile Views</span>
                    </div>
                    <span className="text-lg font-bold text-gray-900">{analytics?.weeklyProfileViews || 0}</span>
                  </div>
                  <p className="text-xs text-gray-500">This week</p>
                  <div className="flex items-center gap-1 mt-1">
                    <TrendingUp size={12} className="text-green-500" />
                    <span className="text-xs text-green-600 font-medium">Total: {analytics?.profileViews || 0} views</span>
                  </div>
                </div>

                {/* Availability Status */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Calendar size={16} className="text-green-600" />
                      <span className="text-sm font-medium text-gray-700">Availability</span>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${analytics?.isAvailable
                      ? 'bg-green-100 text-green-700'
                      : 'bg-red-100 text-red-700'
                      }`}>
                      {analytics?.isAvailable ? 'Available' : 'Busy'}
                    </span>
                  </div>
                  <p className="text-xs text-gray-500">
                    {analytics?.isAvailable ? 'Ready for new projects' : 'Currently unavailable'}
                  </p>
                </div>

                {/* Quick Actions */}
                <div className="space-y-2">
                  <Link
                    href="/edit-profile"
                    className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <span className="text-sm font-medium text-gray-700">Update Profile</span>
                    <ExternalLink size={14} className="text-gray-400" />
                  </Link>
                  <Link
                    href="/edit-profile#portfolio"
                    className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <span className="text-sm font-medium text-gray-700">Manage Portfolio</span>
                    <ExternalLink size={14} className="text-gray-400" />
                  </Link>
                  <Link
                    href="/availability"
                    className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <span className="text-sm font-medium text-gray-700">Set Availability</span>
                    <ExternalLink size={14} className="text-gray-400" />
                  </Link>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </ProtectedRoute>
  );
}